namespace InheritanceInEFCore.Models{
    public class Burger : FoodItem
    {
        public bool HasCheese { get; set; }
    }
}