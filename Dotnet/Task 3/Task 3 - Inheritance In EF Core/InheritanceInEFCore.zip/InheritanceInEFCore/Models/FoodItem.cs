namespace InheritanceInEFCore.Models{
    public class FoodItem
    {
        public int FoodItemId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string FoodType { get; set; } 
    }
}