namespace InheritanceInEFCore.Models{
    public class Pizza : FoodItem
    {
        public int NumberOfToppings { get; set; }
    }
}